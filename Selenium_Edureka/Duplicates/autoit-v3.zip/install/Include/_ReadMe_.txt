This directory contains pre-written functions for use in your AutoIt scripts.

Include the functions using:

#include <Filename.au3>

See the help file for details of the functions, or read the .au3 directly.