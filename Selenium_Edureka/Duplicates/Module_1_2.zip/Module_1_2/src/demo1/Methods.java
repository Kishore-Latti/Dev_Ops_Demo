package demo1;

public class Methods {
	

	public void day()
	{
		System.out.println( " Today is Saturday");
	}
	
	public void month()
	{
		System.out.println( " It is December");
	}
	
	public void year()
	{
		System.out.println( "It is 2016");
		
	}
	
	static public void getMethods()
	{
		System.out.println(" represent static method");
	}
	
	
}
