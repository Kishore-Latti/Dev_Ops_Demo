package com.uttesh.pdfngreport;

import org.testng.Assert;
import org.testng.annotations.Test;

public class DeepalicrbiggggggggggggggggggggggggggggtextTest {

    @Test
    public void testQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQA(){
        Assert.assertEquals("A", "B");
    }

    @Test
    public void testB() {
        Assert.assertEquals("B", "B");
    }

    @Test
    public void testC() {
        Assert.assertEquals("C", "c");
    }
}
