package com.uttesh.pdfngreport;

import org.testng.SkipException;
import org.testng.annotations.Test;

public class SmitJainTest {

    @Test
	public void Page1Test() {
         throw new SkipException("Skipping - This is not ready for testing ");
	}
    @Test
	public void Page2Test() {
         throw new SkipException("Skipping - This is not ready for testing ");
	}
    @Test
	public void Page3Test() {
         throw new SkipException("Skipping - This is not ready for testing ");
	}
    @Test
	public void Page4Test() {
         throw new SkipException("Skipping - This is not ready for testing ");
	}
    @Test
	public void Page5Test() {
         throw new SkipException("Skipping - This is not ready for testing ");
	}
}
