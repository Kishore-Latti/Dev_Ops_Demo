pdfngreport demo
================

demo for the pdfngreport plugin, in this sample we are going to use the plugin and generate the pdf report.
