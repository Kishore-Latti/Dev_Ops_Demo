THIS SOFTWARE IS NO LONGER BEING MAINTAINED. VERSION 1.1.4 IS THE FINAL RELEASE.
IF YOU WOULD LIKE TO MAKE YOUR OWN UPDATES, YOU CAN FORK IT. PULL REQUESTS TO
THIS REPOSITORY WILL BE IGNORED.

Download latest version of ReportNG from either of the following:

https://dl.dropboxusercontent.com/u/14133069/reportng-1.1.4.tgz
https://dl.dropboxusercontent.com/u/14133069/reportng-1.1.4.zip

Full instructions on how to use ReportNG can be found here:

http://reportng.uncommons.org
