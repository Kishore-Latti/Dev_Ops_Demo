package com.edureka.simpleenum;


enum Colors_enum {red , green , blue , white , yellow }


public class Main {

	public static void main(String[] args) {
		
		Colors_enum colors[]= Colors_enum.values();
		
		
		System.out.println(colors[1]);
		
		System.out.println();
		
		for(Colors_enum c : colors)
			{
				System.out.println(c);
				System.out.println();
			}

	}

}
