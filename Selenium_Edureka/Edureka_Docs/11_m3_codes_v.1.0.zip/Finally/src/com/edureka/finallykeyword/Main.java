package com.edureka.finallykeyword;

public class Main {

	public static void main(String[] args) {
		
		try
		{
			System.out.println("Entered Try block");
			throw new Exception("exception is thrown");
		}
		
		catch (Exception e) {
			System.out.println("Entered catch block");
			System.out.println(e);
		}
		finally
		{
			System.out.println("Entered finally block even exception has occured");
		}

		
	}

}
