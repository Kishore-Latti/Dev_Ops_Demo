package com.edureka.userdefinedexception;

public class Grade extends Exception {

	int marks1;
	int marks2;
	int marks3;
	int marks4;

	Grade() {
	}

	Grade(String str)
	{
		super(str);
	}

	Grade(int marks1, int marks2, int marks3, int marks4) {
		this.marks1 = marks1;
		this.marks2 = marks2;
		this.marks3 = marks3;
		this.marks4 = marks4;
	}

	public void findGrade() {
		int marks[] = { marks1, marks2, marks3, marks4 };
		double total = 0;
		double totaloutofmarks = 400;
		double percentage;
		try {
			for (int i = 0; i < marks.length; i++) {

				if (marks[i] >= 40) {
					total += marks[i];

				} else {
					throw new Grade("Sorry");
				}
			}

			percentage = (total / totaloutofmarks) * 100;

			if (percentage >= 75.0) {
				System.out.println("You got Grade A");
			} else if (percentage >= 70.0 && percentage < 75.0) {
				System.out.println("You got Grade B");
			} else if (percentage >= 65.0 && percentage < 70.0) {
				System.out.println("You got Grade C");
			} else if (percentage >= 60.0 && percentage < 65.0) {
				System.out.println("You got Grade D");

			} else if (percentage >= 40.0 && percentage < 60.0) {
				System.out.println("You just passed in Examination");
			} else {

			}
		} catch (Grade ne) {
			System.out.println("error" + ne
					+ " you did not excel you are failed");

		}

	}
}
