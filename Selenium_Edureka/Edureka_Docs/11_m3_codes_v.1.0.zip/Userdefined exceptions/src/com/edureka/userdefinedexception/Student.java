package com.edureka.userdefinedexception;

public class Student {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

			Grade Student1= new Grade(60,70,80,14);
			Grade Student2= new Grade(40,40,40,40);
			Grade Student3= new Grade(70,60,53,76);
			Student1.findGrade();
			Student2.findGrade();
			Student3.findGrade();
	}

}
