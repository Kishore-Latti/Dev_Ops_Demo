package com.edureka.collection.hashtable;

import java.util.Enumeration;
import java.util.Hashtable;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Create a hash map
		Hashtable hashtable = new Hashtable();

		// Putting elements
		hashtable.put("Ankita", 9634.58);
		hashtable.put("Vishal", 1283.48);
		hashtable.put("Gurinder", 1478.10);
		hashtable.put("Krishna", 199.11);
		
		// Using Enumeration
		Enumeration enumeration = hashtable.keys();

		// Display elements
		while (enumeration.hasMoreElements()) {
			String key = enumeration.nextElement().toString();

			String value = hashtable.get(key).toString();
			
			System.out.println(key + ":"+value);
		}

	}

}
