package com.edureka.collection.hashmap;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public class Main {

	public static void main(String[] args) {
		
	
			// Create a hash map
			HashMap<String, Double> hashmap = new HashMap<String, Double>();
		
			// Putting elements
			hashmap.put("Ankita",9634.58);
			hashmap.put("Vishal", 1283.48);
			hashmap.put("Gurinder", 1478.10);
			hashmap.put("Krishna", 199.11);
		
			// Get an iterator
			Iterator<Entry<String, Double>> iterator = hashmap.entrySet().iterator();
		
			// Display elements
			while (iterator.hasNext()) {
				Map.Entry entry = (Map.Entry) iterator.next();
				System.out.print(entry.getKey() + ": ");
				System.out.println(entry.getValue());
			}

	}
}
