package com.edureka.exception.throwkeyword;

import java.io.IOException;

public class Student {

Student(int studentid,String name){
	try	{
		if(studentid==0)
			throw new Exception("id can not be zero");
		else
			System.out.println("The id of "+name+" is:"+studentid);
	    }
	catch (Exception e) {
		// handle exception
		System.out.println(e);
	}
}

}
