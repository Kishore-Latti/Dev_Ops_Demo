package com.edureka.enums;
enum Chocolates{

	Diarymilk(20),
	Kitkat(10), 
	Munch(5);
	int cost;
	Chocolates(int cost)
	{
		this.cost = cost;
	}
	
}
		
public class Main {
	public static void main(String[] args) {
		
		Chocolates favouritechoco=Chocolates.Munch;
		
		Chocolates list[]=Chocolates.values();
		
		System.out.println("Your favourite item is : " +favouritechoco);
	
		switch(favouritechoco)
		{
		    case Diarymilk: System.out.println("The cost of Diary Milk is:" +list[0].cost); 
		    				break;
		    case Kitkat: System.out.println("The cost of KitKat is: " +list[1].cost ); 	
		    			break;
		    case Munch: System.out.println("The cost of Munch is: "+list[2].cost); 
		    			break;
		}
	}

}
