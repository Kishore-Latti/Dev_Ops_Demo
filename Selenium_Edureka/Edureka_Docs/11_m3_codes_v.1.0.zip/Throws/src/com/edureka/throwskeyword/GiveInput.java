package com.edureka.throwskeyword;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class GiveInput {
	
	void takeInput() throws IOException
	{
		BufferedReader reader=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter your name");
		String name=reader.readLine();
		System.out.println("Your name is: "+name);
	}

}
