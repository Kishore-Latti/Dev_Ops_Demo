package com.edureka.exception.trycatch;

import java.util.Scanner;

public class Try_Catch {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a number");
		 int y=sc.nextInt();
		 try{
			  if(y==0)
			  {
				  	System.out.println( 5/y);
			  }
			  else
			  {
				  System.out.println("exception has not occured. to see exception enter zero");
			  }
			  y=sc.nextInt();
			  System.out.println(5/y);
		  }
		  catch(ArithmeticException e) {
		  System.out.println("Divide By Zero Exception");
		 }

	}

}
