package com.edureka.collection.arraylist;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Create an arraylist
		ArrayList<String> arraylist = new ArrayList<String>();

		// Adding elements
		arraylist.add("Rose");
		arraylist.add("Lilly");
		arraylist.add("Jasmine");
		arraylist.add("Rose");

		//removes element at index 2
		arraylist.remove(2);
	

		// Display elements
		Iterator<String> iterator = arraylist.iterator();

		// Display elements
		while (iterator.hasNext()) {
			String element = iterator.next().toString();
			System.out.print(element + " ");
			
		}


		
	}

}
