package com.edureka.exception.multiplecatch;

public class Main {

	
	public static void main(String[] args) {
		
		Multiple_Catch  multiplecatch1=new Multiple_Catch(0);
		Multiple_Catch  multiplecatch2=new Multiple_Catch(5);
		

	}

}
