package com.edureka.exception.multiplecatch;
class Multiple_Catch {
	int n;
	int array[]=new int[3];
	
	Multiple_Catch(int n)
	{
			try{
				if(n==0)
					System.out.println(5/n);
				else{
					array[3]=n;
					System.out.println(array);
				}
			}
			catch(ArrayIndexOutOfBoundsException arrayexception){
				System.out.println(arrayexception);
			}
			catch (ArithmeticException divideexception) {
				System.out.println(divideexception);
			}
	}
}
