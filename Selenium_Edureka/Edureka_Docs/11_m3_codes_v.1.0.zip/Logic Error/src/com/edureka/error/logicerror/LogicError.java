package com.edureka.error.logicerror;

public class LogicError {

	
	public static void main(String[] args) {
		
		System.out.println("This is Logic error program");
		System.out.println("This program is for printing numbers 1-5");
		int i=0;
		
		for(i=0;i<5;i++)
		
		
		
		{
			System.out.println(i+1);
		}

	}

}
