package com.edureka.error.designerror;

public class DesignError {

	
	public static void main(String[] args) {
		
		System.out.println("This is Design-time error");

	}

}
