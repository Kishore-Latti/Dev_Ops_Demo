package co.edureka.selenium.grid;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class TestGrid {
	
	WebDriver driver;
	String baseUrl, nodeUrl;
	
	public void testGrid(){
		
		baseUrl = "http://www.facebook.com/";
		nodeUrl = "http://192.168.1.3:5555/wd/hub";
		DesiredCapabilities  cap = DesiredCapabilities.chrome();
		cap.setBrowserName("chrome");
		cap.setPlatform(Platform.WINDOWS);
		try {		
			driver = new RemoteWebDriver(new URL(nodeUrl), cap);
		}		
		catch (MalformedURLException e) {			
			e.printStackTrace();
		}			
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get(baseUrl);
		loginToFacebook();
		
	}
	
	public void loginToFacebook(){
		driver.findElement(By.id("email")).sendKeys("akanksha24.a@gmail.com");
		driver.findElement(By.id("pass")).sendKeys("password");
		driver.findElement(By.id("loginbutton")).click();
	}

	public static void main(String[] args) {
		TestGrid obj = new TestGrid();
		obj.testGrid();	

	}

}
