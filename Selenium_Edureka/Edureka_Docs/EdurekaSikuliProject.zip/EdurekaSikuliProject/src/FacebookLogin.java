import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;


public class FacebookLogin {
	
	WebDriver driver;
	Screen myScreen;
	
	public void invokeBrowser() {

		System.setProperty("webdriver.chrome.driver",
				"D:\\Akanksha\\Selenium\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.get("http://www.facebook.com");
		
	}
	
	public void signInUsingSikuli(){
		try {
			Pattern userId = new Pattern("C:\\Users\\AkkiAsh\\Desktop\\Edureka\\Sikuli code Files\\FB-ID.PNG");
			Pattern password = new Pattern("C:\\Users\\AkkiAsh\\Desktop\\Edureka\\Sikuli code Files\\FB-PASS.PNG");
			Pattern loginButton = new Pattern("C:\\Users\\AkkiAsh\\Desktop\\Edureka\\Sikuli code Files\\FB-LOGIN.PNG");
			
			myScreen = new Screen();
			myScreen.wait(userId, 3);
			myScreen.type(userId, "akanksha24.a@gmail.com");
			myScreen.type(password, "password");
			myScreen.click(loginButton);
			
		} catch (FindFailed e) {			
			e.printStackTrace();
		}		
		
	}

	public static void main(String[] args) {
		FacebookLogin obj = new FacebookLogin();
		obj.invokeBrowser();
		obj.signInUsingSikuli();
		

	}

}
