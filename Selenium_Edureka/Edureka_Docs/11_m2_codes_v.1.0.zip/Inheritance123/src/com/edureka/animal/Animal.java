package com.edureka.animal;

public class Animal {

	int fun(int a , int b) {
		int sum = a + b;
		return sum;
	}
	
	double fun(double a, double b, double c)
	{
		double sum = a + b + c;
		return sum;
		
	}
}
