package com.edureka.animal;

public class Aquatic extends Animal{



	String s = "Child Classs";

}
