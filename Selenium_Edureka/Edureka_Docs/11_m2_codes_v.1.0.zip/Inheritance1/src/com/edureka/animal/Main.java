package com.edureka.animal;

public class Main {

	public static void main(String[] args) {
		
		Aquatic ob = new Aquatic();
		
		System.out.println("Aquatic animals are "+ ob.Type + " and lives "+ ob.Lives);
		
		Aquatic ob1 = new Aquatic("Vineet");
		System.out.println("Aquatic animals are "+ ob1.Type + " and lives "+ ob1.Lives);
		
	}
}
