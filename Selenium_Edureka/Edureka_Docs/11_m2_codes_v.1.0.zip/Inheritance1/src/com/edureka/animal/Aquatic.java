package com.edureka.animal;


public class Aquatic extends Animal{
	String Type;
	
	public Aquatic()
	{
	Type  = "bashkjg";
	
	}
	
	public Aquatic ( String x)
	{
		super();
	}
	
	final String Lives = "In Water";
	

}
