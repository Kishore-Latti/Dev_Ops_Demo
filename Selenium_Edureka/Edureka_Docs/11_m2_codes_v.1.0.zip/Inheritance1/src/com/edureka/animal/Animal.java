package com.edureka.animal;

public class Animal {

	
	
	String Type  = "Not Human";
	//public String Lives = "On Land";
	
	public Animal(){
		
		
		this.Type = "Not Human";
	}
	
//	public Animal(String x){
//		Type = "Not Human";
//	}
	
}
