package com.edureka.pack2;

import com.edureka.pack1.Example;

public class Simple {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Example object =new Example();
		object.display();
		
	}

}
