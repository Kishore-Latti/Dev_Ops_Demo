package com.edureka.pack1;

public class Example {

	public void display()
	{
		System.out.println("hi This is class in another package");
	}

}
