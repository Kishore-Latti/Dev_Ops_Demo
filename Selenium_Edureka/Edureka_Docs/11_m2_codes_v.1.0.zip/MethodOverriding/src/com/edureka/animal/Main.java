package com.edureka.animal;

public class Main {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
    
		Aquatic ob = new Aquatic();
        System.out.println("Product by derived class : " +""+ ob.fun(2,3));

	}

}
 