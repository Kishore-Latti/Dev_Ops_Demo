package com.edureka.animal;

public class Animal {
	
//	static int a;
//	static int b;

	int  fun(int a, int b){
	
		int c =  a + b;
	      return c;
	      
	     }


	
}
