
public abstract class Class1 {
	
	abstract void Area ();
	
	abstract void fun2();
	
	void fun()
	{
		System.out.println("Abstract Class");
	}
	

}
