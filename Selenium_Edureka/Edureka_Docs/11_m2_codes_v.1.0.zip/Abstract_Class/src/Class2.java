
public class Class2 extends Class1{

	@Override
	void Area() {
		// TODO Auto-generated method stub
		System.out.println("Finding the Area");
	}

	@Override
	void fun2() {
		// TODO Auto-generated method stub
		System.out.println("In a class that extends abtract class");
	}

}
