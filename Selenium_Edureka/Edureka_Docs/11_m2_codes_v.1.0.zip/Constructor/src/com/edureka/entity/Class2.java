package com.edureka.entity;

public class Class2 {

	int x;
	int y;
	
	public Class2()
	{
		x = 10;
		y = 11;
	}

	
	public Class2(int z)
	{
		x = z;
		y = z;
		
	}
}
