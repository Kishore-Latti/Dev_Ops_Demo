package com.edureka.superkeyword;

public class Main {

	public static void main(String[] args) {
		
		Parent parent = new Parent();
		
		Child child = new Child();
		
		parent.display();
		child.display();

	}

}
