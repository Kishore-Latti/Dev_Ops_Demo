package com.edureka.superkeyword;

public class Parent {

	int x  = 10;
	
	void display()
	{
		System.out.println("This is display method from Parent Class ");
	}
	
}
