package com.edureka.ouput;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("hello");
		
		int input='a';
		System.out.write(input);//takes only one character
		System.out.write('\n');

	}

}
