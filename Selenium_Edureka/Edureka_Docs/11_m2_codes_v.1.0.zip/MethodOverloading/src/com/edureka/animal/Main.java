package com.edureka.animal;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Animal ob = new Animal();
//        
//		 //without Parameters, defined in class Animal
//		 ob.fun();  
//		
//			
//		//with Parameter, overloaded function in class Aquatic
//		          ob.fun(10);  

//		Animal ob = new Animal();
		
		ob.add(5, 6);
		
		ob.add(6.1, 6.2);
	}

}
