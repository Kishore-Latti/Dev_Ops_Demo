
public interface Class1 {
	
	int add(int x, int y);
	void print(int sum);

}
