
public class Class2 implements Class1{

	@Override
	public int add(int x, int y) {
		// TODO Auto-generated method stub
		
		
		return (x+y) ;
	}

	@Override
	public void print(int sum) {
		// TODO Auto-generated method stub
		System.out.println(sum);
	}

}
