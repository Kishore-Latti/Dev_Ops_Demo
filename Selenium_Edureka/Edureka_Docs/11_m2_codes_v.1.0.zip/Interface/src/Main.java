
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Class2  ob  = new Class2();
		
		ob.print(  ob.add(10, 10) );
		

	}

}
