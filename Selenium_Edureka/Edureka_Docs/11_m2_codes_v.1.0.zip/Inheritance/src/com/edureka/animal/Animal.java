package com.edureka.animal;

public class Animal {
	
		public String Type = "Not Human";
		

//		public void fun()
//		{
//
//		}

}
