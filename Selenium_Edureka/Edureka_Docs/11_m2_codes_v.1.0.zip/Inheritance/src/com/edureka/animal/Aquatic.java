package com.edureka.animal;

public class Aquatic extends Animal{

	String Lives = "In Water";
	
//	public void fun(){
//		
//	              System.out.println("defined here");
//	       }
}
