public class Edureka {

	static public Integer coun;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 
		//String Declaration
		String vineet;
		String Vineet = new String();
		
		int x =5;
		
		//Initializing the static variable and printing its value
		coun = 3;
		 System.out.println(coun);
		 
		 //making a object of class File2
		 File2 ob = new File2();
		 
		 //Accessing the method using the object we declared and printing its value. 
		 // Also seeing that the value of static variable has changed
		 ob.fun();
		 System.out.println(coun);

		 //The if and else construct
		 if(coun >7)
		 {
		 System.out.println("correct");
		 }
		 else
		 {
		 System.out.println("incorrect");
		 }

		 //The switch case statement
		 switch (x) {
		 case 1:
		 System.out.println("case1");
		 break;
		
		 case 2:
		 System.out.println("case2");
		 break;
		
		 default:
		 System.out.println("default");
		 break;
		 }

		 //The for loop
		 for(int i =9;i>=0;i--)
		 {
		 System.out.println(i);
		 }
		 
		 //The while loop
		 int z = 0;
		
		 while (z<6)
		 {
		 System.out.println(z);
		 z++;
		
		 }
		
		 //The for-each syntax
		 String []obj = {"vineet"};
		 for(String item : obj)
		 {
		
		 }
		 
		 //Making an object of the class i.e File2
		File2 ob1 = new File2();

		//Using the add function through the object and printing its value
		System.out.println(ob1.add(5, 10));

	}

}
