
public class File2 {
	
	//Declaring and Defining a method in which static variable has been declared
	void fun()
	{
		Edureka.coun = 6;
	}
	
	//Declaring and defining a function which a returs a value to the calling class
	public int add(int x, int y)
	{
		int z;
		z = x+y;
		return z;
	}


}
